<template>
    <d2-container>
        查询统计 统计汇总
    </d2-container>
</template>

<script>
export default {

}
</script>
