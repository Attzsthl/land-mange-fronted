<template>
    <d2-container>
        查询统计 信息查询
    </d2-container>
</template>

<script>
export default {

}
</script>
